# RUET-ChatBot
It's a PHP, MySQL, Jquery ChatBot For My University RUET

# Demo

<a href="https://ruetchatbot.000webhostapp.com/">RUET ChatBot</a>


# Install
```
From Database Folder Import chat.sql into your database
Run Your Server
Type localhost/chatbot/chatbot.php on your Browser
```





